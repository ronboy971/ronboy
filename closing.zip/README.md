# Script Closing

Script de closing interactif en 7 phases pour appels de prospection téléphone (offre site web 300€).

## Stack

- HTML/CSS/JS vanilla, zéro dépendance
- Aucun build, aucun serveur
- Dark theme, mobile-first

## Structure

```
.
├── index.html      # Tout est dedans
├── vercel.json     # Headers de sécurité + config
└── README.md
```

## Déploiement

### Option 1 — Drag & drop sur Vercel

1. Va sur https://vercel.com/new
2. Drag & drop le dossier complet
3. Deploy

### Option 2 — Via GitHub (recommandé)

```bash
cd script-closing-vercel
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin git@github.com:TON_USER/script-closing.git
git push -u origin main
```

Puis sur https://vercel.com/new : Import Git Repository → choisir ton repo → Deploy.

### Option 3 — Vercel CLI

```bash
npm i -g vercel
cd script-closing-vercel
vercel
```

## Domaine personnalisé

Une fois déployé sur Vercel :

1. Settings → Domains → Add
2. Tape `script.jozef.fr` (ou `closing.jozef.fr`)
3. Vercel te donne un enregistrement CNAME
4. Ajoute le CNAME dans la zone DNS de jozef.fr chez ton registrar
5. ~5 min plus tard, c'est en ligne avec HTTPS automatique

## Modifier le contenu

Tout le texte est dans `index.html`, dans le `<script>` en bas de page :
- Fonctions `buildPhase0()` à `buildPhase6()` pour les 7 phases
- Helpers réutilisables : `blockTuDis()`, `blockBlue()`, `blockYellow()`, `branch()`, etc.

Pour changer les couleurs : balise `<style>` → bloc `:root` → variables CSS (`--red`, `--green`, `--yellow`, `--blue`).
